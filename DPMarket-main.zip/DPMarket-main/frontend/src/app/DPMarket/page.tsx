import { redirect } from "next/navigation";

export default function toHome() {
	redirect(`/DPMarket/Buy`);
};